//Eksportering
namespace RacingEventsAPI.Controllers;

//Importering
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]

public class ImageUploadController : ControllerBase
{
    private readonly IWebHostEnvironment environment;
    

    public ImageUploadController(IWebHostEnvironment _environment)
    {
        environment = _environment;
    }

//POST-metode for bildefiler
    [HttpPost]
    public IActionResult PostImageFile(IFormFile imageFile)
    {
        
        try
        {
            string webRootPath = environment.WebRootPath;
            string absolutePath = Path.Combine($"{webRootPath}/images/{imageFile.FileName}");

            using(var fileStream = new FileStream(absolutePath, FileMode.Create))
            {
            imageFile.CopyTo(fileStream);
            }

            //Sjekker om filen har bildefil og om den har innhold
            if(imageFile.ContentType.Contains("image") && imageFile.Length > 0)
            {
                return Ok(imageFile);
            }
            else
            {
                return NotFound();
                
            }
        }
        catch
        {   
            return StatusCode(500);
        }

    }
}