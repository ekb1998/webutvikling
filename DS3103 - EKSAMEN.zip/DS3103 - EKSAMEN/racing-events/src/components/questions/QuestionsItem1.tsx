//Importering
import IQuestion1 from "../../interfaces/IQuestion1";
import { FC } from "react";
//Lager en komponent som henter egenskaper fra interface iQuestion1
const QuestionsItem1: FC<IQuestion1> = ({
  age,
  nameAnswerA,
  nameAnswerB,
  nameAnswerC,
  nationality,
  handleAnswer,
  btnColorA,
  btnColorB,
  btnColorC,
  status,
}) => {
  return (
    <article
      className="text-center bg-dark p-4 text-light"
      style={{ height: "600px" }}
    >
      <h5>Spørsmål 1</h5>
      <p>
        Hvilken sjåfør er {age} år og kommer fra {nationality}?
      </p>
      <div>
        <button
          onClick={handleAnswer}
          className={`m-4 btn ${btnColorA}`}
          name="option-1"
        >
          A: {nameAnswerA}
        </button>
      </div>

      <div>
        <button
          onClick={handleAnswer}
          className={`m-4 btn ${btnColorB}`}
          name="option-2"
        >
          B: {nameAnswerB}
        </button>
      </div>
      <div>
        <button
          onClick={handleAnswer}
          className={`m-4 btn ${btnColorC}`}
          name="option-3"
        >
          C: {nameAnswerC}
        </button>
      </div>
      <div>
        <span>{status}</span>
      </div>
    </article>
  );
};
//Eksportering
export default QuestionsItem1;
