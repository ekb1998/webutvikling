//Interface for hva en sjåfør må inneholde

interface IDriver {
  name: string;
  image: string;
  age: number;
  nationality: string;
  level: string;
}

export default IDriver;
