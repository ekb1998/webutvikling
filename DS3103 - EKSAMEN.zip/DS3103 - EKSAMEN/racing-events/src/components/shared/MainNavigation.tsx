//Importering
import { Link } from "react-router-dom";
//Lager en felles komponent for hele løsningen, da alle sidene skal ha felles navigering
const MainNavigation = () => {
  return (
    <header>
      <nav className="navbar navbar-expand bg-secondary">
        <div className="container-fluid">
          <div className="navbar-header">
            <img src="/images/car.png" className="img-fluid" />
            Special Event
          </div>
          <ul className="nav navbar-nav ms-auto">
            <li className="nav-item m-2 text-white">
              <Link to="/" className="text-black">
                Hjem
              </Link>
            </li>
            <li className="nav-item m-2">
              <Link to="drivers" className="text-black">
                Påmeldte sjåfører
              </Link>
            </li>
            <li className="nav-item m-2">
              <Link to="registration" className="text-black">
                Registrering
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  );
};
//Eksportering
export default MainNavigation;
