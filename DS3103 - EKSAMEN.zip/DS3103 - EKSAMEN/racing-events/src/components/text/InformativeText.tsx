//Komponent som genererer tekst til HomePage
const InformativeText = () => {
  return (
    <section className="m-5 p-4">
      <h1>Velkommen til formel 1 event</h1>
      <p>
        Hold av dagen 15.mai 2024, dette vil du ikke gå glipp av! Vi arrangerer
        et spesielt event hvor både amatører og profesjonelle kan kjøre mot
        hverandre. Racet vil starte på campuset til høyskolen Kristiania, i
        urtegata 9. Bruk denne siden til å se deltakere, melde deg på, endre
        deltakelse eller slette deltakelse eller som underholdning til å teste
        ut dine kunnskaper.
      </p>
    </section>
  );
};

//Eksportering
export default InformativeText;
