//Interface for hva spørsmål 1 må inneholde
interface IQuestion1 {
  age: number;
  nameAnswerA: string;
  nameAnswerB: string;
  nameAnswerC: string;
  nationality: string;
  //Funksjon tildelt samme parameter som fra questionslist1
  handleAnswer(): any;
  btnColorA: string;
  btnColorB: string;
  btnColorC: string;
  status: string;
}

export default IQuestion1;
