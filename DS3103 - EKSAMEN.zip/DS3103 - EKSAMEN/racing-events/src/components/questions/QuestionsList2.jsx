//Importering
import QuestionsItem2 from "./QuestionsItem2";
import RacingService from "../../services/RacingService";
import { useState, useEffect } from "react";

const QuestionsList2 = () => {
  //Bruker useState for å sette farge på knappene fra item, default er light
  const [btnColorA, setBtnColorA] = useState("btn-light");
  const [btnColorB, setBtnColorB] = useState("btn-light");
  const [btnColorC, setBtnColorC] = useState("btn-light");
  const [status, setStatus] = useState("...");

  //funksjon som håndterer fargene på knappene og setter dem etter hva som er riktig svar og feil svar.
  //Og skriver ut status tekst for å gi tilbakemelding til brukeren
  const handleAnswer = (e) => {
    switch (e.currentTarget.name) {
      case "option-1":
        setBtnColorA("btn-danger");
        setBtnColorB("btn-light");
        setBtnColorC("btn-light");
        setStatus("feil svar, prøv igjen");
        break;
      case "option-2":
        setBtnColorA("btn-light");
        setBtnColorB("btn-success");
        setBtnColorC("btn-light");
        setStatus("riktig svar");
        break;
      case "option-3":
        setBtnColorA("btn-light");
        setBtnColorB("btn-light");
        setBtnColorC("btn-danger");
        setStatus("feil svar, prøv igjen");
        break;
    }
  };

  const [drivers, setDriver] = useState([""]);

  useEffect(() => {
    getFromService();
  }, []);

  const getFromService = async () => {
    const driversFromService = await RacingService.getAll();
    setDriver(driversFromService);
  };

  //filterer sjåfører etter gitt id fra parameteret
  const filterDriverOnID = (id) => {
    const filterDrivers = drivers.filter((driver) => driver.id === id);
    return filterDrivers;
  };

  const getDriversJSX = () => {
    const filterDrivers = filterDriverOnID(6);
    const filterDrivers2 = filterDriverOnID(1);
    const filterDrivers3 = filterDriverOnID(5);

    const driversJSX = filterDrivers.map((drivers, i) => (
      <QuestionsItem2
        key={i}
        name={drivers.name}
        //Henter nasjonalitet på sjåfør basert på id gitt i parameteret til funksjon findDriverByID
        nationalityAnswerA={filterDrivers2[i].nationality}
        nationalityAnswerB={filterDrivers[i].nationality}
        nationalityAnswerC={filterDrivers3[i].nationality}
        handleAnswer={handleAnswer}
        btnColorA={btnColorA}
        btnColorB={btnColorB}
        btnColorC={btnColorC}
        status={status}
      ></QuestionsItem2>
    ));
    return driversJSX;
  };

  return <section className="row">{getDriversJSX()}</section>;
};
//Eksportering
export default QuestionsList2;
