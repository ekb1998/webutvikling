import DriverList from "../components/drivers/DriverList";

const DriversPage = () => {
  return (
    <section>
      <div>
        <DriverList />
      </div>
    </section>
  );
};

export default DriversPage;
