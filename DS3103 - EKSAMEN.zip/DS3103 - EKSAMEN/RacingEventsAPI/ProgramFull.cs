//Importering
using RacingEventsAPI.Contexts;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//Plassering og navngivning av databasen
builder.Services.AddDbContext<DriversContext>(
    options => options.UseSqlite("Data Source=Databases/DriversDB.db")
);

//Angir policy, gir tilgjengelighet til alle forespørseler
builder.Services.AddCors(
    builder => {
        builder.AddPolicy("AllowEverything",
            policies => policies
                .AllowAnyHeader()
                .AllowAnyMethod()
                .AllowAnyOrigin()
        );
    }
);

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//Gjør bruk av policy
var app = builder.Build();

app.UseCors("AllowEverything");

//Gjør det mulig å koble opp til wwwroot filen, der det inneholder statiske filer som html
app.UseStaticFiles();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
