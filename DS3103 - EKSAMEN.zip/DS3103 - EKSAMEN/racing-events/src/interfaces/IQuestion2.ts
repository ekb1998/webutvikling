//Interface for hva spørsmål 2 må inneholde
interface IQuestion2 {
  name: string;
  nationalityAnswerA: string;
  nationalityAnswerB: string;
  nationalityAnswerC: string;
  handleAnswer(): any;
  btnColorA: string;
  btnColorB: string;
  btnColorC: string;
  status: string;
}

export default IQuestion2;
