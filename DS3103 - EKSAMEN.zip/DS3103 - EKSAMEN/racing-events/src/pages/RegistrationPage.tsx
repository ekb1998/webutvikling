import AddDriver from "../components/drivers/AddDriver";
import DeleteDriver from "../components/drivers/DeleteDrivers";
import EditDriver from "../components/drivers/EditDriver";
import { DriversProvider } from "../contexts/DriversContext";

const RegistrationPage = () => {
  return (
    <DriversProvider>
      <div className="container-fluid">
        <div className="row mt-5">
          <AddDriver />
          <DeleteDriver />
          <EditDriver />
        </div>
      </div>
    </DriversProvider>
  );
};

export default RegistrationPage;
