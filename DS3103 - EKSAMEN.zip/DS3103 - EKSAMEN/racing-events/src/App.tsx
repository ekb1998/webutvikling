import { DriversPage, HomePage, RegistrationPage } from "../src/pages";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import MainNavigation from "./components/shared/MainNavigation";

function App() {
  return (
    <>
      <BrowserRouter>
        <MainNavigation />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />}></Route>
            <Route path="drivers" element={<DriversPage />}></Route>
            <Route path="registration" element={<RegistrationPage />}></Route>
          </Routes>
        </main>
      </BrowserRouter>
    </>
  );
}

export default App;
