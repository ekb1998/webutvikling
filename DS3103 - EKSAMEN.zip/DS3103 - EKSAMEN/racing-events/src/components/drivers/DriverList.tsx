//Importering
import RacingService from "../../services/RacingService";

import { useEffect, useState } from "react";
import DriverItem from "./DriverItem";
import IDriver from "../../interfaces/IDriver";

const DriverList = () => {
  //Oppretter en tilstand basert på interfacet IDriver
  const [drivers, setDriver] = useState<IDriver[]>();

  //Kjører getDriverFromService når det er nødvendig, ved f.eks. endringer
  useEffect(() => {
    getDriversFromService();
  }, []);

  //Henter data om sjåfører fra service, oppdaterer tilstanden til setdriver
  const getDriversFromService = async () => {
    const driversFromService = await RacingService.getAll();
    setDriver(driversFromService);
  };

  //Funksjonen genererer tsx fra item
  const getDriversItem = () => {
    //Henter opp bilde url
    const imgUrl = RacingService.getImgUrl();
    return drivers?.map((drivers, i) => (
      <DriverItem
        key={i}
        name={drivers.name}
        image={`${imgUrl}/${drivers.image}`}
        age={drivers.age}
        nationality={drivers.nationality}
        level={drivers.level}
      />
    ));
  };

  return (
    <section>
      <h3>Sjåfører</h3>
      <p>Antall påmeldte sjåfører: {drivers?.length}</p>

      <section className="row">{getDriversItem()}</section>
    </section>
  );
};
//Eksportering
export default DriverList;
