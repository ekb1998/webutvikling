import { useState, useContext } from "react";
import { DriversContext } from "../../contexts/DriversContext.jsx";

const AddDriver = () => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [nationality, setNationality] = useState("");
  const [level, setLevel] = useState("professional");
  const [image, setImage] = useState(null);

  const { addDriver } = useContext(DriversContext);
  const [status, setStatus] = useState("...");
  //Håndtering av endring
  const handleChange = (e) => {
    switch (e.currentTarget.name) {
      case "name":
        setName(e.currentTarget.value);
        break;
      case "age":
        setAge(e.currentTarget.value);
        break;
      case "nationality":
        setNationality(e.currentTarget.value);
        break;
      case "level":
        setLevel(e.currentTarget.value);
        break;
      case "image":
        setImage(e.currentTarget.files[0]);
        break;
    }
  };
  //Funksjon for å ta bort innhold i input felt
  const removeInputValue = () => {
    setName("");
    setAge("");
    setNationality("");
    setLevel("professional");
    setImage(null);
  };

  //Lagrer sjåfør
  const saveDriver = async () => {
    //Alle felt må være fylt ut for å bli registrert, hvis ikke får bruker feilmelding
    if (name && age && nationality && level && image) {
      const newDriver = {
        name: name,
        age: age,
        nationality: nationality,
        level: level,
        image: image.name,
      };
      const result = await addDriver(newDriver, image);
      setStatus(`${name} er nå registrert for racet`);
      removeInputValue();
    } else {
      setStatus("feilmelding, du må fylle ut alle feltene");
    }
  };

  return (
    <section className="col-12 col-md-6 col-lg-4 bg-dark text-light border">
      <h3>Meld deg på racet</h3>
      <div className="mb-4">
        <label> Navn</label>
        <div>
          <input
            value={name}
            className="w-50"
            onChange={handleChange}
            type="text"
            name="name"
          />
        </div>
      </div>
      <div className="mb-4">
        <label>Alder</label>
        <div>
          <input
            value={age}
            className="w-50"
            onChange={handleChange}
            type="text"
            name="age"
          />
        </div>
      </div>
      <div className="mb-4">
        <label>Nasjonalitet</label>
        <div>
          <input
            value={nationality}
            className="w-50"
            onChange={handleChange}
            type="text"
            name="nationality"
          />
        </div>
      </div>
      <div className="mb-4">
        <label>Level</label>
        <div>
          <select onChange={handleChange} className="p-2 w-50" name="level">
            <option value="professional">Professional</option>
            <option value="amateur">Amateur</option>
          </select>
        </div>
      </div>
      <div className="mb-4">
        <label className="p-2">Bilde</label>
        <div>
          <input onChange={handleChange} type="file" name="image" />
        </div>
      </div>
      <span>{status}</span>
      <div>
        <button onClick={saveDriver} className="btn btn-lg btn-success m-2">
          Send inn
        </button>
      </div>
    </section>
  );
};

export default AddDriver;
