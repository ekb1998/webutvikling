//Interface for hva spørsmål 3 må inneholde
interface IQuestion3 {
  image: string;
  nameAnswerA: string;
  nameAnswerB: string;
  nameAnswerC: string;
  handleAnswer(): any;
  btnColorA: string;
  btnColorB: string;
  btnColorC: string;
  status: string;
}

export default IQuestion3;
