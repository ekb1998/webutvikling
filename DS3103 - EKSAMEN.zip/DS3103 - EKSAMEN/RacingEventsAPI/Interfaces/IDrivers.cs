//Eksportering
namespace RacingEventsAPI.Interfaces;

//Interface = hva en Driver må ha
public interface IDrivers
{
    int Id {get; set;}
    string? Name {get; set;}
    int Age {get; set;}
    string? Nationality {get; set;}
    string? Image {get; set;}
    string? Level {get; set;}
}
