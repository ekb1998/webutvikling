/*HTML objekter*/
const outputAmount = document.querySelector("#output-amount");

/*HTTP funksjon*/
const getAllDrivers = async () => {
  try {
    const result = await axios.get("http://localhost:5207/api/Drivers");
    return result.data;
  } catch {
    console.log("error");
  }
};

/*funksjon som skriver ut antall sjåfører lagret i databasen */
const numberOfDrivers = async () => {
  const test = await getAllDrivers();
  const count = test.length;
  let htmlTxt = `Det er totalt: ${count} sjåfører i APIet `;
  outputAmount.innerHTML = htmlTxt;
};

/*Init funksjon */
(() => {
  numberOfDrivers();
})();
