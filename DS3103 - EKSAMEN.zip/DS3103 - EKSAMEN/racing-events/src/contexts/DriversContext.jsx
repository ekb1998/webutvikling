//Importering
import { createContext, useState, useEffect } from "react";
import RacingService from "../services/RacingService";

export const DriversContext = createContext(null);

export const DriversProvider = ({ children }) => {
  const [drivers, setDrivers] = useState([]);

  useEffect(() => {
    getDriversFromService();
  }, []);

  const getDriversFromService = async () => {
    const driversFromService = await RacingService.getAll();
    setDrivers(driversFromService);
  };

  //Henter sjåfør etter id
  const getById = async (id) => {
    const driversUpdate = await RacingService.getById(id);
    return driversUpdate;
  };

  //Henter sjåfør etter navn
  const getByName = async (name) => {
    const result = await RacingService.getByName(name);
    return result;
  };

  //Endrer sjåførinformasjon
  const editDrivers = async (driversUpdate) => {
    const findUpdatedDriver = drivers.map((driver) => {
      //Sjekker om id er samme som den oppdaterte sjåføren
      if (driver.id === driversUpdate.id) {
        //returneres endret objekt
        return driversUpdate;
      } else {
        //returneres uendret objekt
        return driver;
      }
    });
    await RacingService.putDrivers(driversUpdate);
    //Opdaterer kun objektet som er endret
    setDrivers(findUpdatedDriver);
  };

  //Sletter sjåfør
  const deleteDrivers = async (id) => {
    const result = await RacingService.deleteDrivers(id);
    return result;
  };

  //Legger til sjåfør
  const addDriver = async (newDriver, image) => {
    const result = await RacingService.postDriver(newDriver, image);
    return result;
  };

  return (
    <DriversContext.Provider
      value={{
        drivers,
        getByName,
        getById,
        editDrivers,
        deleteDrivers,
        addDriver,
      }}
    >
      {children}
    </DriversContext.Provider>
  );
};
