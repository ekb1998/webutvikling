import QuestionsItem3 from "./QuestionsItem3";
import RacingService from "../../services/RacingService";
import { useState, useEffect } from "react";

const QuestionsList3 = () => {
  //Bruker useState for å sette farge på knappene fra item, default er light
  const [btnColorA, setBtnColorA] = useState("btn-light");
  const [btnColorB, setBtnColorB] = useState("btn-light");
  const [btnColorC, setBtnColorC] = useState("btn-light");
  const [status, setStatus] = useState("...");

  //funksjon som håndterer fargene på knappene og setter dem etter hva som er riktig svar og feil svar.
  //Og skriver ut status tekst for å gi tilbakemelding til brukeren
  const handleAnswer = (e) => {
    switch (e.currentTarget.name) {
      case "option-1":
        setBtnColorA("btn-danger");
        setBtnColorB("btn-light");
        setBtnColorC("btn-light");
        setStatus("feil svar, prøv igjen");
        break;
      case "option-2":
        setBtnColorA("btn-light");
        setBtnColorB("btn-danger");
        setBtnColorC("btn-light");
        setStatus("feil svar, prøv igjen");
        break;
      case "option-3":
        setBtnColorA("btn-light");
        setBtnColorB("btn-light");
        setBtnColorC("btn-success");
        setStatus("riktig svar");
        break;
    }
  };

  const [drivers, setDriver] = useState([""]);

  useEffect(() => {
    getFromService();
  }, []);

  const getFromService = async () => {
    const driversFromService = await RacingService.getAll();
    setDriver(driversFromService);
  };
  //filterer sjåfører etter gitt id fra parameteret
  const filterDriverOnID = (id) => {
    const filterDrivers = drivers.filter((driver) => driver.id === id);
    return filterDrivers;
  };

  const getDriversJSX = () => {
    const filterDrivers = filterDriverOnID(2);
    const filterDrivers2 = filterDriverOnID(1);
    const filterDrivers3 = filterDriverOnID(7);
    //Henter opp bilde url
    const imgUrl = RacingService.getImgUrl();
    const driversJSX = filterDrivers.map((drivers, i) => (
      <QuestionsItem3
        key={i}
        image={`${imgUrl}/${drivers.image}`}
        //Henter navnet på sjåfør basert på id gitt i parameteret til funksjon findDriverByID
        nameAnswerA={filterDrivers2[i].name}
        nameAnswerB={filterDrivers3[i].name}
        nameAnswerC={filterDrivers[i].name}
        handleAnswer={handleAnswer}
        btnColorA={btnColorA}
        btnColorB={btnColorB}
        btnColorC={btnColorC}
        status={status}
      ></QuestionsItem3>
    ));
    return driversJSX;
  };
  return <section className="row">{getDriversJSX()}</section>;
};
//Eksportering
export default QuestionsList3;
