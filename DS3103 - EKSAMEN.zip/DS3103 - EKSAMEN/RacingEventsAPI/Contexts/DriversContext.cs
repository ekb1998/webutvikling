//Eksportering
namespace RacingEventsAPI.Contexts;

//Importering
using RacingEventsAPI.Models;
using Microsoft.EntityFrameworkCore;

//Klasse som tar i bruk en klasse, for å bli en context-klasse
public class DriversContext : DbContext
{
    //Konstruktør
    public DriversContext(DbContextOptions<DriversContext> options):base(options){}
    //Forteller at jeg ønsker en tabell av drivers i databasen
    public DbSet<Drivers> Drivers{get; set;}
}

