//Importering
import { DriversContext } from "../../contexts/DriversContext.jsx";
import { useState, useContext } from "react";

const DeleteDrivers = () => {
  //får tilgang til funksjoner fra context
  const { deleteDrivers, getByName, getById } = useContext(DriversContext);

  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [status, setStatus] = useState("...");

  //funksjoner som håndterer endring og oppdaterer
  const handleChange = (e) => {
    setId(e.currentTarget.value);
  };

  const handleNameChange = (e) => {
    setName(e.currentTarget.value);
  };

  //Funksjon som tømmer teksten i input feltet
  const removeInputValue = () => {
    setId("");
    setName("");
  };

  const clickButton = async () => {
    const resultName = await getByName(name);
    const resultId = await getById(id);

    //Sjekker at id er 9 eller mindre og om navn stemmer overrens med id, disse sjåførene blir brukt i quizen og skal derfor ikke slettes
    //bruker toLowerCase for å akseptere både store og små bokstaver
    if (
      resultId.id <= 9 &&
      resultName &&
      resultId &&
      resultId.name.toLowerCase() === name.toLowerCase()
    ) {
      setStatus("Denne sjåføren skal delta, så du kan ikke slette. ");
    } else if (
      resultName &&
      resultId &&
      resultId.name.toLowerCase === name.toLowerCase
    ) {
      const result = await deleteDrivers(id);
      setStatus(`Du har nå slettet data med id:${id} og navn: ${name}`);
      removeInputValue();
    } else {
      setStatus("Id og navn stemmer ikke overens");
    }
  };

  return (
    <section className="col-12 col-md-6 col-lg-4 bg-dark text-light border">
      <h3>Avmeld deg fra racet</h3>
      <span>Tast inn id og navn for å melde deg av</span>
      <div className="p-2">
        <label>Id</label>
      </div>
      <div>
        <input
          className="w-50"
          onChange={handleChange}
          value={id}
          type="text"
          name="id"
        ></input>
      </div>
      <div className="p-2">
        <label>Navn</label>
      </div>
      <div>
        <input
          className="w-50"
          onChange={handleNameChange}
          type="text"
          name="name"
          value={name}
        ></input>
      </div>
      <div className="p-2">
        <span>{status}</span>
      </div>
      <button className="btn btn-lg btn-danger mt-5" onClick={clickButton}>
        Slett påmelding
      </button>
    </section>
  );
};
//Eksportering
export default DeleteDrivers;
