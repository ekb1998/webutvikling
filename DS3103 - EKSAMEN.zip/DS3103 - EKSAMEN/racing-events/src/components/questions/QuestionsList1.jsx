//Importering
import QuestionsItem1 from "./QuestionsItem1";
import RacingService from "../../services/RacingService";
import { useState, useEffect } from "react";

const QuestionsList1 = () => {
  //Bruker useState for å sette farge på knappene fra item, default er light
  const [btnColorA, setBtnColorA] = useState("btn-light");
  const [btnColorB, setBtnColorB] = useState("btn-light");
  const [btnColorC, setBtnColorC] = useState("btn-light");
  const [status, setStatus] = useState("...");

  //funksjon som håndterer fargene på knappene og setter dem etter hva som er riktig svar og feil svar.
  //Og skriver ut status tekst for å gi tilbakemelding til brukeren
  const handleAnswer = (e) => {
    switch (e.currentTarget.name) {
      case "option-1":
        setBtnColorA("btn-success");
        setBtnColorB("btn-light");
        setBtnColorC("btn-light");
        setStatus("riktig svar");
        break;
      case "option-2":
        setBtnColorA("btn-light");
        setBtnColorB("btn-danger");
        setBtnColorC("btn-light");
        setStatus("feil svar, prøv igjen");
        break;
      case "option-3":
        setBtnColorA("btn-light");
        setBtnColorB("btn-light");
        setBtnColorC("btn-danger");
        setStatus("feil svar, prøv igjen");
        break;
    }
  };

  const [drivers, setDriver] = useState([""]);

  useEffect(() => {
    getFromService();
  }, []);

  //Henter data om sjåfører fra service, oppdaterer tilstanden til setdriver
  const getFromService = async () => {
    const driversFromService = await RacingService.getAll();
    setDriver(driversFromService);
  };
  //filterer sjåfører etter gitt id fra parameteret
  const filterDriverOnId = (id) => {
    const filterDrivers = drivers.filter((driver) => driver.id === id);
    return filterDrivers;
  };

  const getDriversJSX = () => {
    const filterDrivers = filterDriverOnId(1);
    const filterDrivers2 = filterDriverOnId(2);
    const filterDrivers3 = filterDriverOnId(3); //Angir id i parameteret

    const driversJSX = filterDrivers.map((drivers, i) => (
      <QuestionsItem1
        key={i}
        age={drivers.age}
        nameAnswerA={drivers.name}
        //Henter navnet på sjåfør basert på id gitt i parameteret til funksjon findDriverByID
        nameAnswerB={filterDrivers2[i].name}
        nameAnswerC={filterDrivers3[i].name}
        nationality={drivers.nationality}
        handleAnswer={handleAnswer}
        btnColorA={btnColorA}
        btnColorB={btnColorB}
        btnColorC={btnColorC}
        status={status}
      ></QuestionsItem1>
    ));
    return driversJSX;
  };

  return <section className="row">{getDriversJSX()}</section>;
};
//Eksportering
export default QuestionsList1;
