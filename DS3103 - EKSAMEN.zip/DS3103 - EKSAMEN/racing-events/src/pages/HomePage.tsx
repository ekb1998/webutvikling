import QuestionsList1 from "../components/questions/QuestionsList1";
import QuestionsList2 from "../components/questions/QuestionsList2";
import QuestionsList3 from "../components/questions/QuestionsList3";
import InformativeText from "../components/text/InformativeText";

const HomePage = () => {
  return (
    <section>
      <InformativeText />
      <div className="container">
        <div className="row">
          <h3>Er du en ekte formel-1 fan? Prøv quiz</h3>
          <div className="col-12 col-md-6 col-lg-4">
            <QuestionsList1 />
          </div>
          <div className="col-12 col-md-6 col-lg-4">
            <QuestionsList2 />
          </div>
          <div className="col-12 col-md-6 col-lg-4">
            <QuestionsList3 />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HomePage;
