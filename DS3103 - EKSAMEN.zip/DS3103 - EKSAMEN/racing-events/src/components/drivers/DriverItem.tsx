//Importering
import IDriver from "../../interfaces/IDriver";
import { FC } from "react";

//Lager en komponent som henter egenskaper fra interface IDriver
const DriverItem: FC<IDriver> = ({ name, image, age, nationality, level }) => {
  return (
    <article className="col-12 col-md-6 col-lg-4 p-3">
      <div className="border border-black text-center bg-danger">
        <h4>{name}</h4>
        <img src={image} height="300px" alt="" />
        <p>Alder: {age}</p>
        <p>Nasjonalitet: {nationality}</p>
        <p>Level: {level}</p>
      </div>
    </article>
  );
};

export default DriverItem;
