import DriversPage from "./DriversPage";
import HomePage from "./HomePage";
import RegistrationPage from "./RegistrationPage";

export {
    DriversPage,
    HomePage,
    RegistrationPage
}