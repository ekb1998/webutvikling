//Eksportering
namespace RacingEventsAPI.Models;
//Import av interface
using RacingEventsAPI.Interfaces;

public class Drivers : IDrivers
{
    public int Id {get; set;}
    public string? Name {get; set;}
    public int Age {get; set;}
    public string? Nationality {get; set;}
    public string? Image {get; set;}
    public string? Level {get; set;}
}