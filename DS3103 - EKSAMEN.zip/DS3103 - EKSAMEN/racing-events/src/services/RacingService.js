import axios from "axios";

const RacingService = (() => {
  const driversController = "http://localhost:5207/api/drivers";
  const imageUploadController = "http://localhost:5207/api/imageupload";
  const imgUrl = "http://localhost:5207/images";

  const getAll = async () => {
    try {
      const result = await axios.get(driversController);
      //Hvis det er data å hente
      if (result.data.length > 0) {
        return result.data;
      } else {
        console.log("ingen data å hente");
      }
    } catch (error) {
      console.error(
        "Kunne ikke utføre forespørselen, prøv å laste siden på nytt"
      );
      return [];
    }
  };

  const getById = async (id) => {
    try {
      const result = await axios.get(`${driversController}/${id}`);
      //Sjekker om id eksisterer
      if (result.data.id) {
        console.log(`id: ${id} eksisterer`);
        return result.data;
      }
      //Catchen bryter hvis id ikke blir funnet, grunnet 404 status code, derfor har jeg ikke tatt med else
    } catch (error) {
      console.error(`id: ${id} eksisterer ikke`);
      return false;
    }
  };

  const getByName = async (name) => {
    try {
      const result = await axios.get(`${driversController}/GetByName/${name}`);
      //Hvis forespørselen gikk gjennom
      if (result.data) {
        console.log(`navn: ${name} eksisterer`);
        return result.data;
      } else {
        console.log(`navn: ${name} eksisterer ikke`);
        return false;
      }
    } catch (error) {
      console.error("feil ved henting, prøv igjen", error);
      return false;
    }
  };

  const deleteDrivers = async (id) => {
    try {
      const result = await axios.delete(`${driversController}/${id}`);
      //Sjekker status på forespørsel, for variasjon i koden
      if (result.status === 200) {
        return result.data;
      } else {
        return false;
      }
    } catch (error) {
      console.log(error);
      return false;
    }
  };

  const putDrivers = async (driversUpdate) => {
    try {
      const result = await axios.put(driversController, driversUpdate);
      //Sjekker om driversupdate ikke er null og returnerer dataen fra responsen
      if (driversUpdate != null) {
        return result.data;
      } else {
        return false;
      }
    } catch (error) {
      console.log(error);
      return false;
    }
  };

  const postDriver = async (newDriver, image) => {
    try {
      //post forespørsel til driverscontroller
      const result = await axios.post(driversController, newDriver);
      if (result.data !== null && result.data !== undefined) {
        //Sender bilde som fil
        const formData = new FormData();
        formData.append("imageFile", image);

        //post forespørsel til imageuploadcontroller
        const uploadResult = await axios({
          url: imageUploadController,
          method: "POST",
          data: formData,
          headers: { "Content-Type": "multipart/form-data" },
        });
        formData.delete("imageFile");
      } else {
        return false;
      }
    } catch (error) {
      console.error("Feil ved henting, prøv igjen");
      return false;
    }
  };

  //Funksjon som returnerer bilde url
  const getImgUrl = () => {
    return imgUrl;
  };

  return {
    getAll,
    getById,
    getByName,
    deleteDrivers,
    putDrivers,
    postDriver,
    getImgUrl,
  };
})();

export default RacingService;
