import { HttpStatusCode } from "axios";
import { DriversContext } from "../../contexts/DriversContext.jsx";
import { useContext, useState } from "react";

const EditDriver = () => {
  const { getById, editDrivers } = useContext(DriversContext);
  const [id, setId] = useState("");

  const [driversUpdate, setDriversUpdate] = useState({
    name: "",
    age: "",
    nationality: "",
    level: "",
  });

  const [status, setStatus] = useState("...");
  //Funksjon som håndterer endringer
  const handleChange = (e) => {
    switch (e.currentTarget.name) {
      case "id":
        setId(e.currentTarget.value);
        break;
      case "name":
        setDriversUpdate({ ...driversUpdate, name: e.currentTarget.value });
        break;
      case "age":
        setDriversUpdate({ ...driversUpdate, age: e.currentTarget.value });
        break;
      case "nationality":
        setDriversUpdate({
          ...driversUpdate,
          nationality: e.currentTarget.value,
        });
        break;
      case "level":
        setDriversUpdate({ ...driversUpdate, level: e.currentTarget.value });
    }
  };
  //Funksjon som fjerner input
  const removeInputValue = () => {
    setId("");
    setDriversUpdate({ name: "", age: "", nationality: "", level: "" });
  };
  //Funksjon som henter opp id fra databasen, og ser om den er registrert
  const getByIdFromContext = async () => {
    const driversFromContext = await getById(id);
    if (driversFromContext) {
      setDriversUpdate(driversFromContext);
      setStatus(`Id: ${id} eksisterer i databasen`);
    } else {
      setStatus(`Id: ${id} eksisteres ikke i databasen`);
      removeInputValue();
    }
  };
  //Lagrer endringer
  const saveChanges = () => {
    if (editDrivers(driversUpdate)) {
      setStatus(`Endringer lagret`);
      removeInputValue();
    } else {
      setStatus("Feil ved lagring, prøv igjen");
    }
  };

  return (
    <section className="col-12 col-md-6 col-lg-4 bg-dark text-light border">
      <h3>Rediger påmelding</h3>
      <p>
        Har du skrevet noe feil under påmeldingen eller kanskje du har gått fra
        amateur til professional? Endre her
      </p>
      <div className="p-2">
        <label>Id</label>
      </div>
      <div>
        <input
          className="w-50"
          onChange={handleChange}
          value={id}
          type="text"
          name="id"
        ></input>
        <button className="btn btn-primary" onClick={getByIdFromContext}>
          Hent etter id
        </button>
      </div>
      <div className="p-2">
        <label>Navn</label>
      </div>
      <div>
        <input
          className="w-50"
          onChange={handleChange}
          value={driversUpdate.name}
          type="text"
          name="name"
        ></input>
      </div>
      <div>
        <div className="p-2">
          <label>Alder</label>
        </div>
        <div>
          <input
            className="w-50"
            onChange={handleChange}
            value={driversUpdate.age}
            type="text"
            name="age"
          ></input>
        </div>
      </div>
      <div className="p-2">
        <label>Nasjonalitet</label>
      </div>
      <div>
        <input
          className="w-50"
          onChange={handleChange}
          value={driversUpdate.nationality}
          type="text"
          name="nationality"
        ></input>
      </div>
      <div className="p-2">
        <label>Level</label>
      </div>
      <div>
        <input
          className="w-50"
          onChange={handleChange}
          value={driversUpdate.level}
          type="text"
          name="level"
        ></input>
      </div>
      <div>
        <span>{status}</span>
      </div>
      <button className="btn btn-lg btn-success m-2" onClick={saveChanges}>
        Lagre endring
      </button>
    </section>
  );
};

export default EditDriver;
