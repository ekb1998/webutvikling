//Eksportering
namespace RacingEventsAPI.Controllers;

//Importering
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RacingEventsAPI.Contexts;
using RacingEventsAPI.Models;

[ApiController]
[Route("api/[controller]")]

public class DriversController : ControllerBase
{
    // deklarasjon av context
    private readonly DriversContext driversContext;

    //Konstruktør - lager objektet for å ta i bruk context
    public DriversController(DriversContext _driversContext)
    {
        driversContext = _driversContext;
    }


//GET-metode
    [HttpGet]
    public async Task<ActionResult<List<Drivers>>> Get()
    {
        try
        {
            List<Drivers> drivers = await driversContext.Drivers.ToListAsync();
            if(drivers != null)
            {
                return Ok(drivers);
            }
            else
            {
                return NotFound();
            }
        }
        catch
        {
            return StatusCode(500);
        }
    }

//GET-metode, bruker ternary operator istedenfor if/else for variasjon
    [HttpGet("{id}")]
    public async Task<ActionResult<Drivers>> GetById(int id)
    {
        try
        {
            Drivers? drivers = await driversContext.Drivers.FindAsync(id);
            return drivers !=null ? Ok(drivers) : NotFound();
        }
        catch
        {
            return StatusCode(500);
        }
    }


//GET-metode, list fordi registrerte deltakere kan ha samme navn
//Inspirasjon hentet fra Microsoft.(2022).Asynchronous programming Ashttps://learn.microsoft.com/en-us/ef/core/miscellaneous/async
    [HttpGet]
    [Route("[action]/{name}")]
    public async Task<ActionResult<List<Drivers>>> GetByName(string name)
    {
        try
        {
            //Tolower for å gjøre det mulig for brukeren å skrive inn navnet uten å være casesensitiv
            List<Drivers> drivers = await driversContext.Drivers.Where(d => d.Name != null && d.Name.ToLower() == name.ToLower()).ToListAsync();
            if(drivers.Count >= 1)
            {
                return Ok(drivers);
            }
            else
            {
                return NotFound();
            }
        }
        catch
        {
            return StatusCode(500);
        }
    } 

  
//DELETE-metode
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        try
        {
            Drivers? drivers = await driversContext.Drivers.FindAsync(id);
            
            if(drivers != null)
            {
                driversContext.Drivers.Remove(drivers);
                await driversContext.SaveChangesAsync();
                return NoContent();
            }
            else
            {
                return NotFound();
            }
        }
        catch
        {
            return StatusCode(500);
        }
    }

//PUT-metode
    [HttpPut]
    public async Task<IActionResult> Put(Drivers updatedDrivers)
    {
        try
        {
            if(updatedDrivers != null) 
            {
                driversContext.Entry(updatedDrivers).State = EntityState.Modified;
                await driversContext.SaveChangesAsync();
                return NoContent();
            }
            else
            {
                return NotFound();
            }
        }
        catch
        {
            return StatusCode(500);
        }
    }


//POST-metode
    [HttpPost]
    public async Task<IActionResult> Post(Drivers newDriver)
    {
        try
        {
            if(newDriver != null)
            {
                driversContext.Drivers.Add(newDriver);
                await driversContext.SaveChangesAsync();
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        catch
        {
            return StatusCode(500);
        }
}


}


