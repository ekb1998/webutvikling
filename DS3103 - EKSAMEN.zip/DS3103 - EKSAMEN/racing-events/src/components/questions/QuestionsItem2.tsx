//Importering
import IQuestion2 from "../../interfaces/IQuestion2";
import { FC } from "react";
//Lager en komponent som henter egenskaper fra interface iQuestion2
const QuestionsItem2: FC<IQuestion2> = ({
  name,
  nationalityAnswerA,
  nationalityAnswerB,
  nationalityAnswerC,
  handleAnswer,
  btnColorA,
  btnColorB,
  btnColorC,
  status,
}) => {
  return (
    <article
      className="text-center bg-dark p-2 text-light"
      style={{ height: "600px" }}
    >
      <h5>Spørsmål 2</h5>
      <p>Hvilket land kommer {name} fra?</p>
      <div>
        <button
          onClick={handleAnswer}
          className={`m-4 btn ${btnColorA}`}
          name="option-1"
        >
          A: {nationalityAnswerA}
        </button>
      </div>

      <div>
        <button
          onClick={handleAnswer}
          className={`m-4 btn ${btnColorB}`}
          name="option-2"
        >
          B: {nationalityAnswerB}
        </button>
      </div>
      <div>
        <button
          onClick={handleAnswer}
          className={`m-4 btn ${btnColorC}`}
          name="option-3"
        >
          C: {nationalityAnswerC}
        </button>
      </div>
      <div>
        <span>{status}</span>
      </div>
    </article>
  );
};
//Eksportering
export default QuestionsItem2;
